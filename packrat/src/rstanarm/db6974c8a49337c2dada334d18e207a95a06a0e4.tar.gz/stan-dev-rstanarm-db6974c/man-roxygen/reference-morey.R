#' @references
#' Morey, R. D., Hoekstra, R., Rouder, J., Lee, M. D., and Wagenmakers, E. 
#' (2016). The fallacy of placing confidence in confidence intervals. 
#' \emph{Psychonomic Bulletin & Review}. 23(1), 103--123.
