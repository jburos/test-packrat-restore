#' @param formula,data,subset Same as \code{\link[<%= pkg %>]{<%= pkgfun %>}}.
