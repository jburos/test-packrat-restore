#' @param <%= rareargs %> Same as \code{\link[<%= pkg %>]{<%= pkgfun %>}}, but
#'   rarely specified.
