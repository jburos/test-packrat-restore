#' @param x,y In \code{<%= fun %>}, logical scalars indicating whether to
#'   return the design matrix and response vector. In \code{<%= fitfun %>},
#'   a design matrix and response vector.
