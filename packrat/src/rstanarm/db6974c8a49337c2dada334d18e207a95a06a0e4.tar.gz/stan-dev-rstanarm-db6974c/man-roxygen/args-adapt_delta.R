#' @param adapt_delta Only relevant if \code{algorithm="sampling"}. See 
#'   \code{\link{adapt_delta}} for details.
