#' @seealso \code{\link{stanreg-methods}} and 
#' \code{\link[<%= pkg %>]{<%= pkgfun %>}}.
