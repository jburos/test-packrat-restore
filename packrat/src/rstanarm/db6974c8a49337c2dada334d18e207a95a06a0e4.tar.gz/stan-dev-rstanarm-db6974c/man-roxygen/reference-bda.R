#' @references Gelman, A., Carlin, J. B., Stern, H. S., Dunson, D. B., Vehtari,
#'   A., and Rubin, D. B. (2013). \emph{Bayesian Data Analysis.} Chapman & Hall/CRC
#'   Press, London, third edition. <%= bdaRef %>
