#' @param <%= rareargs2 %> Same as \code{\link[<%= pkg %>]{<%= pkgfun %>}}, but 
#'   rarely specified.
