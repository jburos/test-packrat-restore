#' @references 
#' Piironen, J., and Vehtari, A. (2015). Projection predictive variable
#' selection using Stan+R. \url{http://arxiv.org/abs/1508.02502/}
