#' @references 
#' Stan Development Team. (2016). \emph{Stan Modeling Language Users Guide and
#' Reference Manual.} \url{http://mc-stan.org/documentation/}
