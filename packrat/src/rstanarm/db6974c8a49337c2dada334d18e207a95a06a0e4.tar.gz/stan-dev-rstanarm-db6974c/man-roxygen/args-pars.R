#' @param pars An optional character vector of parameter names.
